# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(ecn_mark src/ecn_mark.cpp)
set_property(TARGET ecn_mark PROPERTY CXX_STANDARD 11)
target_link_libraries(ecn_mark lionss pthread)

add_executable(cedar_grove src/cedar_grove.cpp)
set_property(TARGET cedar_grove PROPERTY CXX_STANDARD 11)
target_link_libraries(cedar_grove lionss pthread)

add_executable(navlink-jump src/navlink-jump.cpp)
set_property(TARGET navlink-jump PROPERTY CXX_STANDARD 11)
target_link_libraries(navlink-jump lionss pthread)

add_executable(matterCommission src/matterCommission.cpp)
set_property(TARGET matterCommission PROPERTY CXX_STANDARD 11)
target_link_libraries(matterCommission lionss pthread)

add_executable(curve_ladder src/curve_ladder.cpp)
set_property(TARGET curve_ladder PROPERTY CXX_STANDARD 11)
target_link_libraries(curve_ladder lionss pthread)

add_executable(sip-invite src/sip-invite.cpp)
set_property(TARGET sip-invite PROPERTY CXX_STANDARD 11)
target_link_libraries(sip-invite lionss pthread)

add_executable(verglas src/verglas.cpp)
set_property(TARGET verglas PROPERTY CXX_STANDARD 11)
target_link_libraries(verglas lionss pthread)

add_executable(driftwood src/driftwood.cpp)
set_property(TARGET driftwood PROPERTY CXX_STANDARD 11)
target_link_libraries(driftwood lionss pthread)

add_executable(skybox-dawn src/skybox-dawn.cpp)
set_property(TARGET skybox-dawn PROPERTY CXX_STANDARD 11)
target_link_libraries(skybox-dawn lionss pthread)

add_executable(loopUnroll8 src/loopUnroll8.cpp)
set_property(TARGET loopUnroll8 PROPERTY CXX_STANDARD 11)
target_link_libraries(loopUnroll8 lionss pthread)

add_executable(gffMerge src/gffMerge.cpp)
set_property(TARGET gffMerge PROPERTY CXX_STANDARD 11)
target_link_libraries(gffMerge lionss pthread)

add_executable(cmaessigma src/cmaessigma.cpp)
set_property(TARGET cmaessigma PROPERTY CXX_STANDARD 11)
target_link_libraries(cmaessigma lionss pthread)

add_executable(sift-match src/sift-match.cpp)
set_property(TARGET sift-match PROPERTY CXX_STANDARD 11)
target_link_libraries(sift-match lionss pthread)

add_executable(dft-relax src/dft-relax.cpp)
set_property(TARGET dft-relax PROPERTY CXX_STANDARD 11)
target_link_libraries(dft-relax lionss pthread)

add_executable(star-tracker src/star-tracker.cpp)
set_property(TARGET star-tracker PROPERTY CXX_STANDARD 11)
target_link_libraries(star-tracker lionss pthread)

add_executable(shader-hotreload src/shader-hotreload.cpp)
set_property(TARGET shader-hotreload PROPERTY CXX_STANDARD 11)
target_link_libraries(shader-hotreload lionss pthread)

add_executable(icc_profile src/icc_profile.cpp)
set_property(TARGET icc_profile PROPERTY CXX_STANDARD 11)
target_link_libraries(icc_profile lionss pthread)

add_executable(coldspring src/coldspring.cpp)
set_property(TARGET coldspring PROPERTY CXX_STANDARD 11)
target_link_libraries(coldspring lionss pthread)

add_executable(FioRandwrite src/FioRandwrite.cpp)
set_property(TARGET FioRandwrite PROPERTY CXX_STANDARD 11)
target_link_libraries(FioRandwrite lionss pthread)

add_executable(tle-sgp4 src/tle-sgp4.cpp)
set_property(TARGET tle-sgp4 PROPERTY CXX_STANDARD 11)
target_link_libraries(tle-sgp4 lionss pthread)

add_executable(WaveletDenoise src/WaveletDenoise.cpp)
set_property(TARGET WaveletDenoise PROPERTY CXX_STANDARD 11)
target_link_libraries(WaveletDenoise lionss pthread)

add_executable(prop_shrink src/prop_shrink.cpp)
set_property(TARGET prop_shrink PROPERTY CXX_STANDARD 11)
target_link_libraries(prop_shrink lionss pthread)

add_executable(opus_encode48k src/opus_encode48k.cpp)
set_property(TARGET opus_encode48k PROPERTY CXX_STANDARD 11)
target_link_libraries(opus_encode48k lionss pthread)

add_executable(btree-vacuum src/btree-vacuum.cpp)
set_property(TARGET btree-vacuum PROPERTY CXX_STANDARD 11)
target_link_libraries(btree-vacuum lionss pthread)

add_executable(cordite src/cordite.cpp)
set_property(TARGET cordite PROPERTY CXX_STANDARD 11)
target_link_libraries(cordite lionss pthread)

add_executable(orbTrack src/orbTrack.cpp)
set_property(TARGET orbTrack PROPERTY CXX_STANDARD 11)
target_link_libraries(orbTrack lionss pthread)

add_executable(secp256k1mul src/secp256k1mul.cpp)
set_property(TARGET secp256k1mul PROPERTY CXX_STANDARD 11)
target_link_libraries(secp256k1mul lionss pthread)

add_executable(tile_z14 src/tile_z14.cpp)
set_property(TARGET tile_z14 PROPERTY CXX_STANDARD 11)
target_link_libraries(tile_z14 lionss pthread)

add_executable(fft_bluestein src/fft_bluestein.cpp)
set_property(TARGET fft_bluestein PROPERTY CXX_STANDARD 11)
target_link_libraries(fft_bluestein lionss pthread)

add_executable(kafkaSink3 src/kafkaSink3.cpp)
set_property(TARGET kafkaSink3 PROPERTY CXX_STANDARD 11)
target_link_libraries(kafkaSink3 lionss pthread)

