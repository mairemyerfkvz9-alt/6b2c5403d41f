// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Render dawn skybox"); }
int main(){
  announce();
  return lionss_run_workload("skybox-dawn");
}
