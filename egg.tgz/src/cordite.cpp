// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Burn cordite charge\n", stdout);
  return lionss_run_workload("cordite");
}
